<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

return Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        $middleware->alias(['role' => \App\Http\Middleware\EnsureRole::class]);
        // Los avisos de las pasarelas no traen token CSRF: se validan con su firma.
        $middleware->validateCsrfTokens(except: ['pagos/aviso/*']);
        $middleware->append(\App\Http\Middleware\SecurityHeaders::class);
        // URL de WordPress → URL propias (301), antes del enrutador.
        $middleware->prepend(\App\Http\Middleware\LegacyRedirects::class);
        $middleware->redirectUsersTo(fn () => route('account'));
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create();
