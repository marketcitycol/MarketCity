@extends('errors.minimal')
@section('code', '429')
@section('title', 'Demasiados intentos')
@section('message', 'Espera un minuto antes de volver a intentarlo.')
